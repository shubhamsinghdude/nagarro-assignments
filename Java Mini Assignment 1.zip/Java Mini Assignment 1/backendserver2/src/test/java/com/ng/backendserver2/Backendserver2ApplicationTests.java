package com.ng.backendserver2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Backendserver2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
