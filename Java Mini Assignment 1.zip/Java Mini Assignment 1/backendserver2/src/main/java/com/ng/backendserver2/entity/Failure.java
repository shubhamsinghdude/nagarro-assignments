package com.ng.backendserver2.entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Failure {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long transactionId;
	
	private long accountNumber;
	private String status;
	private int amount;
	private Date date;
	
	public Failure() {
		super();
	}

	public Failure(long accountNumber, long transactionId, String status, int amount, Date date) {
		super();
		this.accountNumber = accountNumber;
		this.transactionId = transactionId;
		this.status = status;
		this.amount = amount;
		this.date = date;
	}
	
	
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}

}
