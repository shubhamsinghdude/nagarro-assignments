package com.ng.backendserver2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.backendserver2.entity.Failure;
import com.ng.backendserver2.repository.FailureRepository;


@Service
public class FailureService {
	
	@Autowired
	private FailureRepository failureRepository;	
	
	//get all Success Data
	public List<Failure> getAllFailure(){
		List<Failure> list=(List<Failure>)failureRepository.findAll();
		return list;
	}
	
	//get single Success Data by id
	public List<Failure> getFailureById(List<Integer> accountNumber) {
		
		List<Failure> allSuccessData = null;
		try {
			allSuccessData = this.failureRepository.findAllById(accountNumber);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return allSuccessData;
	}

}
