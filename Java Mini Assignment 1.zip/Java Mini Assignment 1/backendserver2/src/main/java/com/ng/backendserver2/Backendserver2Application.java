package com.ng.backendserver2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Backendserver2Application {

	public static void main(String[] args) {
		SpringApplication.run(Backendserver2Application.class, args);
	}

}
