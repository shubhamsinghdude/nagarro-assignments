package com.ng.backendserver2.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ng.backendserver2.entity.Failure;

public interface FailureRepository extends JpaRepository<Failure, Integer> {

}
