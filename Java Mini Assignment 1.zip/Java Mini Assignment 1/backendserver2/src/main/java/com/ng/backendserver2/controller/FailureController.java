package com.ng.backendserver2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ng.backendserver2.entity.Failure;
import com.ng.backendserver2.service.FailureService;

@RestController
@RequestMapping("/backendserver2")
public class FailureController {
	
	@Autowired
	private FailureService failureService;
	
	@GetMapping("/failuretest")
	public String test() {
		return "Failure Service Successfully running!";
	}
	
	@GetMapping("/failure")
	public List<Failure> getCustomers(){
		return this.failureService.getAllFailure();
	}
	
	@GetMapping("/failure/{accountNumber}")
	public List<Failure> getCustomer(@PathVariable("accountNumber") List<Integer> accountNumber) {
		return this.failureService.getFailureById(accountNumber);
	}

}
