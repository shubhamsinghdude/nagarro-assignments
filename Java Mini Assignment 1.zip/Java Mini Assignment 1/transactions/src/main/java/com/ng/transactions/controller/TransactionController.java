package com.ng.transactions.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.ng.transactions.entity.Transaction;
import com.ng.transactions.service.TransactionService1;
import com.ng.transactions.service.TransactionService2;
import com.ng.transactions.service.TransactionService3;

@RestController
public class TransactionController {
	
	@Autowired
	TransactionService1 transactionService1;
	
	@Autowired
	TransactionService2 transactionService2;
	
	@Autowired
	TransactionService3 transactionService3;
	
	@GetMapping("/success/{accountNumber}")
	ResponseEntity<List<Transaction>> getSuccessData(@PathVariable long accountNumber){
		return ResponseEntity.ok(transactionService1.getSuccessData(accountNumber));
		
	}
	
	@GetMapping("/failure/{accountNumber}")
	ResponseEntity<List<Transaction>> getFailureData(@PathVariable long accountNumber){
		return ResponseEntity.ok(transactionService2.getFailureData(accountNumber));
		
	}
	
	@GetMapping("/pending/{accountNumber}")
	ResponseEntity<List<Transaction>> getPendingData(@PathVariable long accountNumber){
		return ResponseEntity.ok(transactionService3.getPendingData(accountNumber));
		
	}
	
	ResponseEntity<Map<String, List<Transaction>>> getAllData(@PathVariable long accountNumber){
		
		List<Transaction> successData = transactionService1.getSuccessData(accountNumber);

		List<Transaction> failureData = transactionService2.getFailureData(accountNumber);

		List<Transaction> pendingData = transactionService3.getPendingData(accountNumber);
		
		Map<String, List<Transaction>> allResponse = new HashMap<>();
		allResponse.put("success", successData);
		allResponse.put("failure", failureData);
		allResponse.put("pending", pendingData);
		
		return ResponseEntity.ok(allResponse);
		
	}

}
























