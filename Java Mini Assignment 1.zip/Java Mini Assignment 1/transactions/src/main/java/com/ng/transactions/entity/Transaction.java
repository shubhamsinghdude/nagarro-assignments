package com.ng.transactions.entity;

import java.util.Date;

public class Transaction {
	
	private long transactionId;
	private long accountNumber;
	private String status;
	private int amount;
	private Date date;
	
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Transaction(long transactionId, long accountNumber, String status, int amount, Date date) {
		super();
		this.transactionId = transactionId;
		this.accountNumber = accountNumber;
		this.status = status;
		this.amount = amount;
		this.date = date;
	}

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", accountNumber=" + accountNumber + ", status=" + status
				+ ", amount=" + amount + ", date=" + date + "]";
	}
	
	

}
