package com.ng.transactions.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ng.transactions.entity.Transaction;

@FeignClient(name = "SUCCESS-DATA", url = "http://localhost:8081/")
public interface TransactionService1 {
	
	@GetMapping("/success/{accountNumber}")
	List<Transaction> getSuccessData(@PathVariable long accountNumber);

}
