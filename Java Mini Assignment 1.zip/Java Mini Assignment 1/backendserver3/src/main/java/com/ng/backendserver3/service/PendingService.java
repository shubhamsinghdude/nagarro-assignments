package com.ng.backendserver3.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.backendserver3.entity.Pending;
import com.ng.backendserver3.repository.PendingRepository;


@Service
public class PendingService {
	
	@Autowired
	private PendingRepository pendingRepository;	
	
	//get all Success Data
	public List<Pending> getAllPending(){
		List<Pending> list=(List<Pending>)pendingRepository.findAll();
		return list;
	}
	
	//get single Success Data by id
	public List<Pending> getPendingById(List<Integer> accountNumber) {
		
		List<Pending> allSuccessData = null;
		try {
			allSuccessData = this.pendingRepository.findAllById(accountNumber);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return allSuccessData;
	}

}
