package com.ng.backendserver3.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ng.backendserver3.entity.Pending;
import com.ng.backendserver3.service.PendingService;


@RestController
@RequestMapping("/backendserver3")
public class PendingController {
	
	@Autowired
	private PendingService pendingService;
	
	@GetMapping("/pendingstest")
	public String test() {
		return "Pending Service Successfully running!";
	}
	
	@GetMapping("/pending")
	public List<Pending> getCustomers(){
		return this.pendingService.getAllPending();
	}
	
	@GetMapping("/pending/{accountNumber}")
	public List<Pending> getCustomer(@PathVariable("accountNumber") List<Integer> accountNumber) {
		return this.pendingService.getPendingById(accountNumber);
	}

}
