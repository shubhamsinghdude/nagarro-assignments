package com.ng.backendserver3.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ng.backendserver3.entity.Pending;

public interface PendingRepository extends JpaRepository<Pending, Integer> {

}
