package com.ng.backendserver1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.backendserver1.entity.Success;
import com.ng.backendserver1.repository.SuccessRepository;

@Service
public class SuccessService {
	
	
	@Autowired
	private SuccessRepository successRepository;	
	
	//get all Success Data
	public List<Success> getAllSuccess(){
		List<Success> list=(List<Success>)successRepository.findAll();
		return list;
	}
	
	//get single Success Data by id
	public List<Success> getSuccessById(List<Integer> accountNumber) {
		
		List<Success> allSuccessData = null;
		try {
			allSuccessData = this.successRepository.findAllById(accountNumber);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return allSuccessData;
	}

}
