package com.ng.backendserver1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ng.backendserver1.entity.Success;

public interface SuccessRepository extends JpaRepository<Success, Integer> {

}
