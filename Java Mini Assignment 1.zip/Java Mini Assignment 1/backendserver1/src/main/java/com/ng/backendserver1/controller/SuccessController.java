package com.ng.backendserver1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ng.backendserver1.entity.Success;
import com.ng.backendserver1.service.SuccessService;

@RestController
@RequestMapping("/backendserver1")
public class SuccessController {
	
	@Autowired
	private SuccessService successService;
	
	@GetMapping("/successtest")
	public String test() {
		return "Success Service Successfully running!";
	}
	
	@GetMapping("/success")
	public List<Success> getCustomers(){
		return this.successService.getAllSuccess();
	}
	
	@GetMapping("/success/{accountNumber}")
	public List<Success> getCustomer(@PathVariable("accountNumber") List<Integer> accountNumber) {
		return this.successService.getSuccessById(accountNumber);
	}
	


}
