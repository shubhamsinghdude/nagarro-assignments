package Csv.Project.CsvProject;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;


public class MyThread extends Thread {
	
	String color,size,gender;
	String fileLocation;
	int preference;
	
	public MyThread(String color,String size,String gender,int preference,String fileLocation) {
		this.color = color;
		this.size = size;
		this.gender = gender;
		this.preference = preference;
		this.fileLocation = fileLocation;
	}
	
	@Override
	public void run() {
		
		ArrayList<DataModel> arrayList = new ArrayList<DataModel>();
		PrintData data = new PrintData();
		
		ArrayList<String> arr;
		
		try {
			File myFile = new File(fileLocation);
			Scanner sc = new Scanner(myFile);
			while(sc.hasNextLine()) {
				
				String line = sc.nextLine().toUpperCase().toString();
				if (!line.isEmpty()) {
					StringTokenizer token = new StringTokenizer(line, "|");
					arr = new ArrayList();
					
					
					while (token.hasMoreTokens()) {
						arr.add(token.nextToken());
					}
					
					if (arr.get(2).equals(color) && arr.get(4).equals(size) && arr.get(3).equals(gender)) {
						
						DataModel model = new DataModel(arr.get(0), arr.get(1), arr.get(2), arr.get(3), arr.get(4),
								arr.get(5), arr.get(6), arr.get(7));
						
						arrayList.add(model);
					}
				}
				
			
			}
			data.printAns(arrayList, preference);
			sc.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
}
