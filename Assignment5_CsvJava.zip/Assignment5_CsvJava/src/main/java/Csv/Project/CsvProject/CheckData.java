package Csv.Project.CsvProject;

import java.io.File;

public class CheckData {
	
	public void searchData(String color,String size,String gender,int preference,String location) {
		
		//Fetch the individual file
		File file = new File(location);  
        File[] files = file.listFiles();  
        for (File f:files)  
        {
        	String realLocation = location+"\\"+f.getName();
        	MyThread myThread = new MyThread(color,size,gender,preference,realLocation);
    		myThread.start();
        }  
        
       
		
	}

}
