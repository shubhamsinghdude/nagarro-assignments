package Csv.Project.CsvProject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class PrintData {
	
	public void printAns(ArrayList<DataModel> list,int preference) {
		
		if (preference == 1) {
			Collections.sort(list, new Comparator<DataModel>() {
				public int compare(DataModel o1, DataModel o2) {
					return ((int) ( Integer.parseInt(o1.getPrice()) ));
				}
			});
		} else if (preference == 2) {
			Collections.sort(list, new Comparator<DataModel>() {
				public int compare(DataModel o1, DataModel o2) {
					return ((int) ( Integer.parseInt(o1.getRating()) ));
				}
			});
		} 
		viewTShirt(list);
		
	}
	
	public void viewTShirt(ArrayList<DataModel> list) {
		
		for (DataModel f : list) {
			
			System.out.print(f.getID());
			System.out.print(" | " + f.getName());
			System.out.print(" | "+ f.getColor());
			System.out.print(" | " + f.getGender());
			System.out.print(" | " + f.getSize());
			System.out.print(" | " + f.getPrice());
			System.out.print(" | " + f.getRating());
			System.out.println(" | " + f.getAvailability() + "|");
			System.out.println("---------------------------------------------------------------------------");			
		}
		if(list.isEmpty()) {
			AppConfig.increseQuantity();
		}
		if(AppConfig.cartQuantity == 3) {
			System.out.println("Your cart is empty");
		}
	
	}

}
