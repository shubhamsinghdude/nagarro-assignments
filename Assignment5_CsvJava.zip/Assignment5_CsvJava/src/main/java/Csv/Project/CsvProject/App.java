package Csv.Project.CsvProject;

import java.io.File;
import java.util.Scanner;

public class App 
{
    public static void main( String[] args )
    {
        Scanner sc = new Scanner(System.in);
        String color,size,gender;
        String location="CsvFiles";
        int preference;
        
        while(true) {
        	
        	try {
        		System.out.print("Enter your Color: ");
            	color = sc.nextLine().toUpperCase();
        		System.out.print("Enter your Size(S/M/L/XL): ");
                size = sc.nextLine().toUpperCase();
        		System.out.print("Enter your Gender(M/F): ");
                gender = sc.nextLine().toUpperCase();
        		System.out.print("Enter your Prefernce(1/2)\n1. Sort by Price\n2. Sort by Rating : ");
        		preference = sc.nextInt();
        		if(preference!=1 && preference!=2) {
        			System.out.println("Wrong Choice Entered....Try Again!!.");
        			continue;
        		}
                break;
            }
            catch(NumberFormatException ex) {
            	System.out.println("Please input correctly");
            }
        	catch(Exception ex) {	
        		System.out.println("Something went wrong! Please try again later...!!!");
        	}
        	
        }
        System.out.println();
		System.out.println("  ID  |  NAME  |  COLOUR  |  gender  |  SIZE  |  PRICE  |  RATING  |  AVAILABILITY  |");
	
        CheckData ck = new CheckData();
        ck.searchData(color, size, gender,preference, location); 
        
    }
}
