package Csv.Project.CsvProject;

public class DataModel {
	
	String ID,Name,Color,Gender,Size,Price,Rating,Availability;

	public DataModel(String iD, String name, String color, String gender, String size, String price, String rating,
			String availability) {
		ID = iD;
		Name = name;
		Color = color;
		Gender = gender;
		Size = size;
		Price = price;
		Rating = rating;
		Availability = availability;
	}
	
	
	public DataModel() {
		
	}


	public String getID() {
		return ID;
	}


	public void setID(String iD) {
		ID = iD;
	}


	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}


	public String getColor() {
		return Color;
	}


	public void setColor(String color) {
		Color = color;
	}


	public String getGender() {
		return Gender;
	}


	public void setGender(String gender) {
		Gender = gender;
	}


	public String getSize() {
		return Size;
	}


	public void setSize(String size) {
		Size = size;
	}


	public String getPrice() {
		return Price;
	}


	public void setPrice(String price) {
		Price = price;
	}


	public String getRating() {
		return Rating;
	}


	public void setRating(String rating) {
		Rating = rating;
	}


	public String getAvailability() {
		return Availability;
	}


	public void setAvailability(String availability) {
		Availability = availability;
	}
	
	
	
	
}
