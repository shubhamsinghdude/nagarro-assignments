package Csv.Project.CsvProject;

import java.util.ArrayList;

public class AppConfig {
	
	public static int cartQuantity=0;

	public static int getCartQuantity() {
		return cartQuantity;
	}

	public static void setCartQuantity(int cartQuantity) {
		AppConfig.cartQuantity = cartQuantity;
	}
	
	public static void increseQuantity() {
		cartQuantity +=1;
	}
	
	
}
