package ngshubham.misc;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import ngshubham.model.Product;


public class FilterByType {

	public static List<Product> filterData(List<Product> list, String preference) {
		
		System.out.println(preference);
		System.out.println("priceeee11");

		if (preference.equalsIgnoreCase("price")) {
			System.out.println("priceeee");
		
			Collections.sort(list, new Comparator<Product>() {
				public int compare(Product o1, Product o2) {
					return ((int) (Float.parseFloat(o1.getPrice())));
				}
			});
		} else if (preference.equalsIgnoreCase("rating")) {

			System.out.println("ratingggg");
			Collections.sort(list, new Comparator<Product>() {
				public int compare(Product o1, Product o2) {
					return ((int) (Float.parseFloat(o1.getRating())));
				}
			});
		}
		return list;

	}

}
