package ngshubham.fileController;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import ngshubham.dao.ProductDao;
import ngshubham.model.Product;

public class DataFile {

	String location = "C:\\Users\\shubhamsingh05\\eclipse-workspace\\Assignment8_CsvSpring\\CSV";

	ArrayList<String> arr;

	ProductDao productDao;

	boolean check = false;

	public void FetchFileLocation() {

		

		// Fetch the individual file
		File file = new File(location);
		File[] files = file.listFiles();

		for (File f : files) {
			String realLocation = location + "\\" + f.getName();
			try {
				File myFile = new File(realLocation);
				Scanner sc = new Scanner(myFile);
				while (sc.hasNextLine()) {

					String line = sc.nextLine().toUpperCase().toString();
					if (!line.isEmpty() && check != false) {
						StringTokenizer token = new StringTokenizer(line, "|");
						arr = new ArrayList<String>();

						while (token.hasMoreTokens()) {
							arr.add(token.nextToken());
						}
						try {
							
							SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Product.class)
									.buildSessionFactory();
							Session session = factory.getCurrentSession();

							Product product = new Product();
							product.setId(arr.get(0));
							product.setName(arr.get(1));
							product.setColour(arr.get(2));
							product.setGender_recommendation(arr.get(3));
							product.setSize(arr.get(4));
							product.setPrice(arr.get(5));
							product.setRating(arr.get(6));
							product.setAvailability(arr.get(7));

							session.beginTransaction();
							session.save(product);
							session.getTransaction().commit();
							
							session.close();
							factory.close();

						} catch (Exception e) {
							System.out.println(e);
						}

					}
					check = true;
				}
				check = false;
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

		}
		

	}

}
