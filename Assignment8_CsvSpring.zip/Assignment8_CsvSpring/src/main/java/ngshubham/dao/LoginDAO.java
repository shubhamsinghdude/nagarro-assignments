package ngshubham.dao;

public interface LoginDAO {
	public boolean checkLogin(String username, String password);
}
