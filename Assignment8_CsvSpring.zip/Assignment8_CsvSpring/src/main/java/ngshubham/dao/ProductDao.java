package ngshubham.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import ngshubham.model.Product;

@Component
public class ProductDao {

	@Autowired
	public HibernateTemplate hibernateTemplate;
	
	
	public void uploadProduct(Product product) {
		
		this.hibernateTemplate.save(product);
		
	}
	
	
	public  List<Product> getAllProduct(){
		
		List<Product> allProduct = this.hibernateTemplate.loadAll(Product.class);
		return allProduct;
	}
}
