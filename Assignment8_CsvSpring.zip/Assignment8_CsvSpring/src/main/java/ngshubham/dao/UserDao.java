package ngshubham.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import ngshubham.model.User;

@Component
public class UserDao {
	
	@Autowired
	public HibernateTemplate hibernateTemplate;
	
	
	
	public  List<User> getAllUser(){
		
		List<User> allProduct = this.hibernateTemplate.loadAll(User.class);
		return allProduct;
	}

}
