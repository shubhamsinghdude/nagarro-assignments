package ngshubham.model;


import org.springframework.stereotype.Component;

@Component
public class SearchData {
	

    private String color;
    private String size;
    private String gender_recommendation;
    private String sortingType;
    
    
    
	public SearchData() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	


	public SearchData(String color, String size, String gender_recommendation, String sortingType) {
		super();
		this.color = color;
		this.size = size;
		this.gender_recommendation = gender_recommendation;
		this.sortingType = sortingType;
	}





	public String getColor() {
		return color;
	}



	public void setColor(String color) {
		this.color = color;
	}



	public String getSize() {
		return size;
	}



	public void setSize(String size) {
		this.size = size;
	}



	public String getGender_recommendation() {
		return gender_recommendation;
	}



	public void setGender_recommendation(String gender_recommendation) {
		this.gender_recommendation = gender_recommendation;
	}



	public String getSortingType() {
		return sortingType;
	}

	public void setSortingType(String sortingType) {
		this.sortingType = sortingType;
	}





	@Override
	public String toString() {
		return "SearchData [color=" + color + ", size=" + size + ", gender_recommendation=" + gender_recommendation
				+ ", sortingType=" + sortingType + "]";
	}
	
	
	
    
    
}