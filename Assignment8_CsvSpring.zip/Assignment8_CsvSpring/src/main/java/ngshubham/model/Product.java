package ngshubham.model;


import org.springframework.stereotype.Component;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Component
@Entity
@Table(name="product")
public class Product {
	
    @Id
    @Column(name="id")
    private String id;
    
    @Column(name="name")
    private String name;
    
    @Column(name="colour")
    private String colour;
    
    @Column(name="gender_recommendation")
    private String gender_recommendation;
    
    @Column(name="size")
    private String size;
    
    @Column(name="price")
    private String price;
    
    @Column(name="rating")
    private String rating;
    
    @Column(name="availability")
    private String availability;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public String getGender_recommendation() {
        return gender_recommendation;
    }

    public void setGender_recommendation(String gender_recommendation) {
        this.gender_recommendation = gender_recommendation;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }
    
    
//
//	public Product(String id, String name, String colour, String gender_recommendation, String size, String price,
//			String rating, String availability) {
//		super();
//		this.id = id;
//		this.name = name;
//		this.colour = colour;
//		this.gender_recommendation = gender_recommendation;
//		this.size = size;
//		this.price = price;
//		this.rating = rating;
//		this.availability = availability;
//	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", colour=" + colour + ", gender_recommendation="
				+ gender_recommendation + ", size=" + size + ", price=" + price + ", rating=" + rating
				+ ", availability=" + availability + "]";
	}
    
    
    
    
}
