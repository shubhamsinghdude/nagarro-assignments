package ngshubham.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

import ngshubham.dao.ProductDao;
import ngshubham.misc.FilterByType;
import ngshubham.model.Product;
import ngshubham.model.SearchData;

@Controller
public class MainController {
	
	@Autowired
	private ProductDao productDao;
	
	SearchData tempData;

//	@RequestMapping("/")
//	public String home() {
//		return "index";
//	}
	
//	@RequestMapping("/index")
//	public String loginPage(Model m) {
//		m.addAttribute("title","Login");
//		return "search";
//	}
	
	@RequestMapping("/search")
	public String searchData(Model m) {
		m.addAttribute("title","Search Product");
		return "search_data";
	}
	
	@RequestMapping("/result")
	public String resultShow(Model m) {
		
		List<Product> products = productDao.getAllProduct();
		System.out.print(products);
		
		List<Product> filterProduct = new ArrayList<Product>();
		
		for(int i=0;i<products.size();i++) {
			
			if( products.get(i).getColour().equalsIgnoreCase(tempData.getColor()) 
					&& products.get(i).getSize().equalsIgnoreCase(tempData.getSize())
					&& products.get(i).getGender_recommendation().equalsIgnoreCase(tempData.getGender_recommendation()) ) {
				
				filterProduct.add(products.get(i));
				
			}
		}
		
		List<Product> fp = FilterByType.filterData(filterProduct,tempData.getSortingType());
		m.addAttribute("title","result page");
		m.addAttribute("list",fp);
		return "result";
	}
	
	@RequestMapping(value = "/processform", method = RequestMethod.POST)
	public RedirectView findData(@ModelAttribute SearchData searchData, HttpServletRequest request  ) {
		
		
		System.out.println(searchData);
		tempData = searchData;
		
		RedirectView view = new RedirectView();
		view.setUrl(request.getContextPath()+ "/result");
		return view;
	}
	
//	@RequestMapping(value = "/loginServlet", method = RequestMethod.POST)
//	public RedirectView loginSection(@ModelAttribute User user, HttpServletRequest request  ) {
//		
//		System.out.println(user);
//		DataFile df = new DataFile();
//		df.FetchFileLocation();
//		
//		RedirectView view = new RedirectView();
//		view.setUrl(request.getContextPath()+ "/search");
//		return view;
//	}
	
}
