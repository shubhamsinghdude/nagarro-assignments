package ngshubham.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

import ngshubham.dao.UserDao;
import ngshubham.fileController.DataFile;
import ngshubham.model.User;


@Controller
public class LoginController {
	
	@Autowired
	private UserDao userDao;

	@RequestMapping("/")
	public String home() {
		return "index";
	}
	
	
	@RequestMapping(value = "/loginServlet", method = RequestMethod.POST)
	public RedirectView loginSection(@ModelAttribute User user, HttpServletRequest request  ) {
		
		RedirectView view = new RedirectView();
		
		List<User> userData = userDao.getAllUser();
		
		for(User u : userData) {
			
			if(u.getUsername().equals(user.getUsername()) 
					&& u.getPassword().equals(user.getPassword())) {
				
				DataFile df = new DataFile();
				df.FetchFileLocation();
				
				
				view.setUrl(request.getContextPath()+ "/search");
				return view;
				
			}
		}
		String message = "Username and password incorrect! Please try again";
		request.setAttribute("message", message);
		view.setUrl(request.getContextPath()+ "/");
		return view;
		
	}
	
}

