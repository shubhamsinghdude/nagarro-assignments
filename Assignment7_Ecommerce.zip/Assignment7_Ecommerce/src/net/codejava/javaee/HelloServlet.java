package net.codejava.javaee;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.codejava.dao.ConnectionDao;
import net.codejava.dao.TshirtDao;
import net.codejava.dao.UserDao;
import net.codejava.model.Tshirt;
import net.codejava.model.User;


@WebServlet("/helloServlet")
public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HelloServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		List<Tshirt> arrayList = new ArrayList<Tshirt>();
		try{
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			
			try {
				UserDao udao=new UserDao(ConnectionDao.getCon());
				User user = udao.userLogin(username, password);
				TshirtDao shirtDao = new TshirtDao(ConnectionDao.getCon());
				arrayList = shirtDao.getAllShirt(username);
				System.out.println(user);
				System.out.println(arrayList);
				if(user != null) {
//					out.print("user login");
					request.setAttribute("username", username);
					
					request.getRequestDispatcher("dashboard.jsp").forward(request, response);
					//request.getSession().setAttribute("user", user);
					//request.setAttribute("user", user);
					//response.sendRedirect(request.getContextPath() + "/dashboard.jsp");
					//response.sendRedirect("index.jsp");
				}else {
					out.print("user login failed");
				}
			} catch (SQLException e) {
				out.print("Check user connectionDao");
			}
			out.print(username+","+password);
		}catch(Exception e) {
			out.print("Check Servlet PArametre");
		}
		
		
	}

}
