package net.codejava.model;

public class Tshirt {
	
	private String shirtid;
	private String username;
	private String title;
	private String quantity;
	private String size;
	private String image;
	
	
	public Tshirt() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Tshirt(String username, String title, String quantity, String size, String image) {
		super();
		this.username = username;
		this.title = title;
		this.quantity = quantity;
		this.size = size;
		this.image = image;
	}

	public Tshirt(String shirtid,String username, String title, String quantity, String size, String image) {
		super();
		this.shirtid = shirtid;
		this.username = username;
		this.title = title;
		this.quantity = quantity;
		this.size = size;
		this.image = image;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}



	public String getTitle() {
		return title;
	}



	public void setTitle(String title) {
		this.title = title;
	}



	public String getQuantity() {
		return quantity;
	}



	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}



	public String getSize() {
		return size;
	}



	public void setSize(String size) {
		this.size = size;
	}



	public String getImage() {
		return image;
	}



	public void setImage(String image) {
		this.image = image;
	}

	public String getShirtid() {
		return shirtid;
	}

	public void setShirtid(String shirtid) {
		this.shirtid = shirtid;
	}

	@Override
	public String toString() {
		return "Tshirt [shirtid=" + shirtid + ", username=" + username + ", title=" + title + ", quantity=" + quantity
				+ ", size=" + size + ", image=" + image + "]";
	}



	
	
	
}
