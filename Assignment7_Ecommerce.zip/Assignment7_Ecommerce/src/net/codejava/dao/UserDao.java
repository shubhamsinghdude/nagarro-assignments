package net.codejava.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import net.codejava.model.Tshirt;
import net.codejava.model.User;

public class UserDao {
	private Connection conn;
	private String query1;
	private String query2;
	private PreparedStatement pst1;
	private PreparedStatement pst2;
	private ResultSet rs1;
	private ResultSet rs2;
	
	public UserDao(Connection conn) {
		super();
		this.conn = conn;
	}

	public User userLogin(String username, String password) {
		User user=null;
		try {
			query1="select * from user where username=? and password=?";
			pst1=this.conn.prepareStatement(query1);
			pst1.setString(1, username);
			pst1.setString(2, password);
			rs1=pst1.executeQuery();
			
			
			if(rs1.next()) {
				user=new User();
				user.setUsername(rs1.getString("username"));
				user.setPassword(rs1.getString("password"));
			}
			
			
		}catch(Exception e){
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return user;
		
	}
	
	public ArrayList<Tshirt> shirtData(String username) {
		ArrayList<Tshirt> arrayList = new ArrayList<Tshirt>();
		Tshirt tshirt = null;
		try {
			query2="select * from product_data where username=?";
			pst2=this.conn.prepareStatement(query2);
			pst2.setString(1, username);
			rs2=pst2.executeQuery();
			
			
			if(rs2.next()) {
				tshirt=new Tshirt();
				tshirt.setUsername(rs2.getString("username"));
				tshirt.setTitle(rs2.getString("title"));
				tshirt.setQuantity(rs2.getString("quantity"));
				tshirt.setSize((rs2.getString("size")));
				tshirt.setImage(rs2.getString("imagelink"));
				arrayList.add(tshirt);
			}
			
			
		}catch(Exception e){
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return arrayList;
		
	}
		
}