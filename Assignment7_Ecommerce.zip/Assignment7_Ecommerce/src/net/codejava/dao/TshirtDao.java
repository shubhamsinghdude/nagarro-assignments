package net.codejava.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import net.codejava.model.Tshirt;

public class TshirtDao {
	
	Connection con;

    public TshirtDao(Connection con) {
        this.con = con;
    }
    
  //add books information to database
    public boolean addProduct(Tshirt shirt){
        boolean test = false;
        
        try{
            String query =  "insert into shirt_data (username,title,quantity,size,image) values(?,?,?,?,?)";
            PreparedStatement pst = this.con.prepareStatement(query);
            pst.setString(1, shirt.getUsername());
            pst.setString(2, shirt.getTitle());
            pst.setString(3, shirt.getQuantity());
            pst.setString(4, shirt.getSize());
            pst.setString(5, shirt.getImage());
            pst.executeUpdate();
            test= true;

        }catch(Exception e){
            e.printStackTrace();
        }
        return test;
    }
    
//  retrieve the book details from databse
    public List<Tshirt> getAllShirt(String username){
    	
        List<Tshirt> shirtList = new ArrayList<>();
        
        try{
            
            String query = "select * from shirt_data where username=?";
            PreparedStatement pt = this.con.prepareStatement(query);
            pt.setString(1, username);
            ResultSet rs = pt.executeQuery();
            
            while(rs.next()){
            	String shirtid = rs.getString("shirtid");
                String username1 = rs.getString("username");
                String title = rs.getString("title");
                String quantity = rs.getString("quantity");
                String size = rs.getString("size");
                String image = rs.getString("image");
                
                Tshirt row = new Tshirt(shirtid,username1,title,quantity,size,image);
                shirtList.add(row);
                
            }
            System.out.println(shirtList);
        }catch(Exception e){
            e.printStackTrace();;
        }
        return shirtList;
    }
    
    
//    edit t shirt information
    public boolean editTshirtInfo(Tshirt shirt){
        boolean check = false;
        try{
            String query = "update shirt_data set shirtid=?, username=?, title=?, quantity=?, size=?, image=? where shirtid=?";
            PreparedStatement pt = this.con.prepareStatement(query);
            pt.setString(1, shirt.getShirtid());
            pt.setString(2, shirt.getUsername());
            pt.setString(3, shirt.getTitle());
            pt.setString(4, shirt.getQuantity());
            pt.setString(5, shirt.getSize());
            pt.setString(6, shirt.getImage());
            pt.setString(7, shirt.getShirtid());
   
            pt.executeUpdate();
            check = true;
        }catch(Exception ex){
            ex.printStackTrace();;
        }
        return check;
        
    }
    
//    get single tshirt information in edit page
    public Tshirt getSingleTshirt(String shirtid){
    	Tshirt shirt = null;
        
        try{
            String query = "select * from shirt_data where shirtid=? ";
            
            PreparedStatement pt = this.con.prepareStatement(query);
            pt.setString(1, shirtid);
            ResultSet rs= pt.executeQuery();
            
            while(rs.next()){
                String username1 = rs.getString("username");
                String title = rs.getString("title");
                String quantity = rs.getString("quantity");
                String size = rs.getString("size");
                String image  = rs.getString("image");
                shirt = new Tshirt(shirtid,username1,title,quantity,size,image);
            }
        }catch(Exception ex){
            ex.printStackTrace();;
        }
        return shirt;
    }
    
    
//    delete books from database
    
    
    public boolean deleteTshirt(String shirtid){
    	boolean check = false;
        try{
            
           String query= "delete from shirt_data where shirtid=?";
           PreparedStatement pt = this.con.prepareStatement(query);
           pt.setString(1, shirtid);
           pt.execute();
           check = true;
            
        }catch(Exception ex){
            ex.printStackTrace();;
        }
        return check;
    }
    

}
