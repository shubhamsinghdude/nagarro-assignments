package naggaro.hibernate.CsvHibernateProject;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class CheckData {

	public void searchData(String colr, String size, String gender, int enterChoice) {

		try {
			Configuration cfg = new Configuration();
			cfg.configure();
			SessionFactory factory = cfg.buildSessionFactory();
			Session session = factory.openSession();

			String choice = "price";
			if (enterChoice == 2) {
				choice = "rating";
			}

			String hql = "from Tshirt t WHERE t.colour = :colr and t.gender_recommendation = :gender and t.size = :size order by t."
					+ choice;
			Query query = session.createQuery(hql);
			query.setParameter("colr", colr);
			query.setParameter("gender", gender);
			query.setParameter("size", size);
			List li = query.list();
			Iterator it = li.iterator();

			if (li.size() == 0) {
				System.out.print("Sorry! Tshirt not available");
			} else {

				System.out.println("\n----- T-SHIRT INFORMATION -----");
				System.out.println();
				System.out.println(" ID  |  NAME  |  COLOUR  |  gender  |  SIZE  |  PRICE  |  RATING   | AVAILABILITY");
				while (it.hasNext()) {
					Object o = (Object) it.next();
					Tshirt st = (Tshirt) o;
					System.out.print(st.getId());
					System.out.print(" | " + st.getName());
					System.out.print(" | " + st.getColour());
					System.out.print(" | " + st.getGender_recommendation());
					System.out.print(" | " + st.getSize());
					System.out.print(" | " + st.getPrice());
					System.out.print(" | " + st.getRating());
					System.out.println(" | " + st.getAvailability());
				}
				session.close();
				factory.close();
			}

		} catch (Exception e) {
			System.out.println("Exception throws in database connection...!");
		}

	}
}
