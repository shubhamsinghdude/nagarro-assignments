package Queue;

public class MyQueue {
	
//	Enqueue
//	Dequeue
//	Peek
//	Contains
//	Size
//	Center
//	Sort
//	Reverse
//	Iterator
//	Traverse/Print

	int size;
	static Node front = null;
	static Node rear = null;
	
	MyQueue(){
		this.size=0;
	}
	
	class Node{
		int data;
		Node next;
		Node(int data){
			this.data=data;
			this.next=null;
			size++;
		}
	}


	public void Enqueue(int data){
		Node new_node = new Node(data);
		if(rear == null){
			rear = front = new_node;
		}
		rear.next= new_node;
		rear=new_node;
	}
	

	public int Dequeue(){
		if(isEmpty()){
			System.out.println("Queue is Empty");
			return -1;
		}
		if(front== rear){
			rear = null;
		}
		size--;
		int temp = front.data;
		front=front.next;
		return temp;
	}
	

	public int Peek(){
		if(isEmpty()){
			System.out.println("Queue is Empty");
		}
		return front.data;
	} 
	

	public int Size(){
		return size;
	}

	
	public void Center(){
		Node first=front;
		Node second = front;
		while(second !=null && second.next !=null ){
			first= first.next;
			second= second.next.next;
		}
		System.out.println("Middle element = "+first.data);
	} 
	
	public void Sort(){
		Node curr= front;
		Node index=null;
		int temp;
		if (isEmpty()){
			System.out.println("Queue is Empty");
			return;
		}
		while(curr != null){
			index = curr.next;
			
			while( index != null){
				if(curr.data > index.data){
					temp = curr.data;
					curr.data = index.data;
					index.data = temp;
				}
				index=index.next;
			}
			curr = curr.next;
		}
	}
	

	public void Reverse(){
		
		if(front==null || front.next==null){
			return;
		}
		Node prev = front;
		Node currNode= front.next;
		while(currNode != null){
			Node nextNode=currNode.next;
			currNode.next=prev;
			prev=currNode;
			currNode=nextNode;
		}
		front.next=null;
		front=prev;
		
	}
	
	public void Iterator(int index){
		
		Node temp = front;
		int cnt = 0;
		while(temp != null){
			if(cnt == index){
				System.out.println("Element at "+index+" postion is: "+temp.data);
			}
				cnt++;
				temp=temp.next;
		}
		
	}
	

	public void Print(){
		
		if(isEmpty()){
			System.out.println("Queue Is Empty");
			return;
		}
		Node currNode=front;
		while(currNode != null){
			System.out.println(currNode.data);
			currNode=currNode.next;
		}
		
	}
	
	public static boolean isEmpty(){
		return front == null && rear == null;
	}
	
	
	public static void main(String[] args) {
		
		MyQueue q = new MyQueue();
		q.Enqueue(2);
		q.Enqueue(4);
		q.Enqueue(6);
		q.Enqueue(8);
		q.Print();
		q.Sort();
		q.Dequeue();
		q.Center();
		System.out.println("Top element of queue: "+q.Peek());
		System.out.println("Size of queue"+q.Size());
		q.Iterator(2);
		q.Reverse();
		q.Print();
	}

	
}
