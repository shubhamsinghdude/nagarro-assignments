package Linked_List;

public class MyLinkedList {
	
	Node head;
	
	public void insert(int data) {
		
		Node new_node = new Node(data);
		new_node.next = head;
		head = new_node;
		
	}
	
	public void insertAtPos(int position,int data) {
		
		Node new_node = new Node(data);
		
		if(position < 1) {
			System.out.print("Your position should be more than 1");
		}else if(position == 1){
			new_node.next = head;
			head = new_node;
		}else {
			Node temp = head;
			for(int i=1;i<position;i++) {
				if(temp!=null)
					temp = temp.next;
			}
			if(temp!=null) {
				new_node.next = temp.next;
				temp.next = new_node;
			}else {
				System.out.print("Your previous node in null");
			}
		}
		
	}
	
	public void delete(int num) {
		
		Node temp = head;
		Node prev = null;
		
		if(temp == null)
			return;
		
		if(temp!=null && temp.data == num) {
			head = temp.next;
			return;
		}
		
		while(temp!=null && temp.data!=num) {
			prev = temp;
			temp = temp.next;
		}
		
		prev.next = temp.next;
		
	}
	
	public void deleteAtPos(int position) {
		
		Node temp = head;
		if(head == null)
			return;
		else if(temp==null || temp.next==null)
			return;
		if(position==0) {
			head = temp.next;
			return;
		}
		
		for(int i=0;temp!=null && i<position-1;i++)
			temp = temp.next;
		
		Node next = temp.next.next;
		temp.next = next;
		
	}
	
	public Node center(Node head) {
		
		Node slow = head;
		Node fast = head;
		while(fast != null && fast.next!=null) {
			slow = slow.next;
			fast = fast.next.next;
		}
		return slow;
		
	}
	
	public void sort() {
		
		Node curr = head;
		Node val = null;
		int temp;
		while(curr!=null) {
			val=curr.next;
			while(val!=null) {
				if(curr.data > val.data) {
					temp = curr.data;
					curr.data = val.data;
					val.data = temp;
				}
				val = val.next;
			}
			curr = curr.next;
		}
		
	}
	
	public int size() {
		
		Node temp = head;
		int count=0;
		while(temp != null) {
			count++;
			temp = temp.next;
		}
		return count;
		
	}
	
	public void reverse() {
		
		Node curr = head;
		Node prev = null;
		Node next = null;
		
		while(curr != null) {
			next=curr.next;
			curr.next=prev;
			prev=curr;
			curr=next;
		}
		head=prev;
		
	}
	
	public void iterator(int val) {
		Node temp = head;
		int count=0;
		while(temp!=null) {
			if(count==val)
				System.out.print("Element at position "+val+" is: "+temp.data);
			count++;
			temp=temp.next;
	
		}
	}

	public void print(Node temp) {
		
		while(temp!=null) {
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
		System.out.println();
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyLinkedList mll = new MyLinkedList();
		mll.insert(5);
		mll.insert(10);
		mll.insert(15);
		mll.insert(20);
		mll.insert(25);
		mll.insert(30);
		mll.insert(35);
		mll.insertAtPos(2, 40);
		System.out.print("Your num is: ");
		mll.print(mll.head);
		int val = mll.size();
		System.out.println("Size is :"+val);
		mll.iterator(50);
		mll.reverse();
		mll.print(mll.head);
		mll.sort();
		mll.print(mll.head);
		
		

	}

}
