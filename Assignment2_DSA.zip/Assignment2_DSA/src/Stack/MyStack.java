package Stack;

public class MyStack {
	
	Node top = null;
	
	public void push(int data) {
		
		Node new_node = new Node(data);
		new_node.next = top;
		top = new_node;
		
	}
	
	public void pop() {
		
		if(top == null) {
			System.out.print("Stack Underflow");
			return;
		}
		top = top.next;
		
	}
	
	public int peek() {
		
		if(!isEmpty()) {
			return top.data;
		}else {
			System.out.print("Your stack is Empty");
			return -1;
		}
		
	}
	
	public void contains() {
		
	}
	
	public int size() {
		int count=0;
		if(top == null) {
			System.out.println("Stack is empty");
			return 0;
		}else {
			Node temp = top;
			while(temp!=null) {
				count++;
				temp = temp.next;
			}
			return count;
		}
	}
	
	public int center() {
		
		Node slow = top;
		Node fast = top;
		while( (fast!=null) && (fast.next!=null) ){
			slow = slow.next;
			fast = fast.next.next;
		}
		return slow.data;
		
	}
	
	public void sort() {
		
		Node curr=top;
		Node idx=null;
    	int temp;
    	if (isEmpty()) {
    		System.out.println("Stack underflow");
    		return;
    	}
    	while(curr!=null) {
    		idx=curr.next;
    		while(idx!=null) {
    			if(curr.data>idx.data) {
    				temp=curr.data;
    				curr.data=idx.data;
    				idx.data=temp;
    			}
    			idx=idx.next;
    		}
    		curr=curr.next;
    	}
		
	}
	
	public void reverse() {
		
		if(top==null || top.next==null) {
    		return;
    	}
    	Node prev=top;
    	Node currnode=top.next;
    	while(currnode != null) {
    		Node nxtnode=currnode.next;
    		currnode.next=prev;
    		prev=currnode;
    		currnode=nxtnode;
    	}
    	top.next=null;
    	top=prev; 
		
	}
	
	public void iterator() {
		
		
		
	}
	
	public void print() {
		
		if(top == null) {
			System.out.print("Stack Underflow");
			return;
		}else {
			Node temp = top;
			while( temp!=null ) {
				System.out.print(temp.data + " ");
				temp = temp.next;
			}
		}
		
	}

	public boolean isEmpty() {
		if(top == null)
			return true;
		return false;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyStack mst = new MyStack();
		mst.push(2);
		mst.push(4);
		mst.push(6);
		mst.push(8);
		mst.push(9);
		mst.print();
		mst.peek();
		int size = mst.size();
		System.out.print("Size is: "+size);
		
		
	}

}
