package Hash_Table;

public class HashTable {

	int[] arr;
    int capacity;
    
    public HashTable(int capacity) {
        this.capacity = nextPrime(capacity);
        arr = new int[this.capacity];
    }
    
    public void insert(int ele) {
        arr[ele % capacity] = ele;
    }
    
    public void clear() {
        arr = new int[capacity];
    }
  
    public boolean contains(int ele){
        return arr[ele % capacity] == ele;
    }
    
    public void delete(int ele) {
        if (arr[ele % capacity] == ele)
            arr[ele % capacity] = 0;
        else
            System.out.println("\nError : Element not found\n");
    }
    
    public int size() {
    	int count=0;
    	for(int i=0;i<arr.length;i++) {
    		if(arr[i]!=0)
    			count++;
    	}
    	return count;
    }
    
    public void printTable() {
        System.out.print("\nHash Table = ");
        for (int i = 0; i < capacity; i++)
            System.out.print(arr[i] +" ");
        System.out.println();
    }
    
    private static int nextPrime( int n ) {
        if (n % 2 == 0)
            n++;
        for (; !isPrime(n); n += 2);
 
        return n;
    }
    
    private static boolean isPrime(int n) {
        if (n == 1 || n % 2 == 0)
            return false;
        for (int i = 2; i<= n/2; i++)
            if (n % i == 0)
                return false;
        return true;
    }
    
	
}
