package Priority_Queue;

public class MyPriorityQueue {

	static class Node {
	    int data;
	    int priority;
	    Node next;	     
	}
	 
	static Node nod = new Node();
	

//	Contains
//	Size
//	Reverse
//	Center
//	Iterator
//	Traverse/Print

	     
	static Node newNode(int d, int p)
	{
		Node temp = new Node();
	    temp.data = d;
	    temp.priority = p;
	    temp.next = null;
	     
	    return temp;
	}

	static int Peek(Node head)
	{
	    return (head).data;
	}

	static Node Dequeue(Node head)
	{
		Node temp = head;
	    (head) = (head).next;
	    return head;
	}
	     
	static Node Enqueue(Node head, int d, int p)
	{
		Node start = (head);
		Node temp = newNode(d, p);
	    if ((head).priority > p) {
	        temp.next = head;
	        (head) = temp;
	    }
	    else {
	        while (start.next != null && start.next.priority < p) {
	            start = start.next;
	        }
	        temp.next = start.next;
	        start.next = temp;
	    }
	    return head;
	}
	
	static int isEmpty(Node head)
	{
	    return ((head) == null)?1:0;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Node pq = newNode(4, 1);
	    pq =Enqueue(pq, 5, 2);
	    pq =Enqueue(pq, 6, 3);
	    pq =Enqueue(pq, 7, 0);
	     
	    while (isEmpty(pq)==0) {
	        System.out.printf("%d ", Peek(pq));
	        pq=Dequeue(pq);
	    }
	}
	
}
