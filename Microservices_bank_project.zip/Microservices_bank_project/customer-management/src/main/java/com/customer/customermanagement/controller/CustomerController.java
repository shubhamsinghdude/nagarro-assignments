package com.customer.customermanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.customer.customermanagement.model.Customer;
import com.customer.customermanagement.service.CustomerService;
import com.customer.customermanagement.service.CustomerServiceImpl;


@RestController
public class CustomerController {
	
//	@Autowired
	private CustomerService customerService;
	
	@GetMapping("/test")
	public String test() {
		return "Test Successful!";
	}
	
	
	@GetMapping("/customer")
	public List<Customer> getCustomers(){
		return this.customerService.getAllCustomers();
	}
	
	@GetMapping("/customer/{id}")
	public Customer getCustomer(@PathVariable("id") int id) {
		return this.customerService.getCustomerById(id);
	}
	
	@PostMapping("/customer")
	public Customer addCustomer(@RequestBody Customer customer) {
		Customer b=this.customerService.addCustomer(customer);
		return customer;
	}
	
	@DeleteMapping("/customer/{id}")
	public ResponseEntity<HttpStatus> deleteCustomer(@PathVariable("id") int id) {
		try {
			this.customerService.deleteCustomer(id);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PutMapping("/customer/{id}")
	public Customer updateCustomer(@RequestBody Customer customer,@PathVariable("id") int id) {
		this.customerService.updateCustomer(customer, id);
		return customer;
	}

}
