package com.customer.customermanagement.service;

import java.util.List;

import com.customer.customermanagement.model.Customer;

public interface CustomerService {
	
	public List<Customer> getAllCustomers();
	
	public Customer getCustomerById(int id);
	
	public Customer addCustomer(Customer customer);
	
	public void deleteCustomer(int id);
	
	public Customer updateCustomer(Customer customer,int id);

}
