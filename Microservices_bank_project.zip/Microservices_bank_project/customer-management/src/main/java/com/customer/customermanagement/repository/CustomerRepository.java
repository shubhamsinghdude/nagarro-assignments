package com.customer.customermanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.customer.customermanagement.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {

}
