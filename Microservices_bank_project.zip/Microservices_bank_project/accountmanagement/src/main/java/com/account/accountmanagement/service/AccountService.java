package com.account.accountmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.accountmanagement.dao.AccountRepository;
import com.account.accountmanagement.model.Account;

@Service
public class AccountService {
	
	@Autowired
	private AccountRepository accountRepository;	
	
	//get all customer
	public List<Account> getAllAccount(){
		List<Account> list=(List<Account>)accountRepository.findAll();
		return list;
	}
	
	//get single customer by id
	public Account getAccountById(int id) {
		Account account=null;
		try {
			account=this.accountRepository.findById(id);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return account;
	}
	
	//update customer
	public void updateAccount(Account account,int accountId) {
		account.setId(accountId);
		accountRepository.save(account);
	}

	
	//add customer
	public Account addAccount(Account a) {
		Account account=accountRepository.save(a);
       return account;
	}
	
	
	//delete customer
	public void deleteAccount(int id) {
		accountRepository.deleteById(id);
	}

}
