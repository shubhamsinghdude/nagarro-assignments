package com.account.accountmanagement.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.account.accountmanagement.model.Account;

public interface AccountRepository extends JpaRepository<Account, Integer> {

	public Account findById(int id);
	
}
