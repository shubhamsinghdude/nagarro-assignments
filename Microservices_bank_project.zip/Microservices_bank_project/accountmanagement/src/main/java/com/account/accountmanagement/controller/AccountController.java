package com.account.accountmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.account.accountmanagement.model.Account;
import com.account.accountmanagement.service.AccountService;

@RestController
public class AccountController {
	
	@Autowired
	private AccountService accountService;
	
	@GetMapping("/test")
	public String test() {
		return "Test Successful!";
	}
	
	
	@GetMapping("/account")
	public List<Account> getCustomers(){
		return this.accountService.getAllAccount();
	}
	
	@GetMapping("/account/{id}")
	public Account getCustomer(@PathVariable("id") int id) {
		return this.accountService.getAccountById(id);
	}
	
	@PostMapping("/account")
	public Account addCustomer(@RequestBody Account account) {
		Account a=this.accountService.addAccount(account);
		return a;
	}
	
	@DeleteMapping("/account/{id}")
	public void deleteCustomer(@PathVariable("id") int id) {
		this.accountService.deleteAccount(id);
	}
	
	@PutMapping("/account/{id}")
	public Account updateCustomer(@RequestBody Account account,@PathVariable("id") int id) {
		this.accountService.updateAccount(account, id);
		return account;
	}

}
