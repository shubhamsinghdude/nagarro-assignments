import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './MyComponent/navbar/navbar.component';
import { TeacherDashComponent } from './MyComponent/Teacher/teacher-dash/teacher-dash.component';
import { TeacherAddNewDataComponent } from './MyComponent/Teacher/teacher-add-new-data/teacher-add-new-data.component';
import { TeacherEditDataComponent } from './MyComponent/Teacher/teacher-edit-data/teacher-edit-data.component';
import { LoginComponent } from './MyComponent/login/login.component';
import { StudentDashComponent } from './MyComponent/Student/student-dash/student-dash.component';
import { StudentResultComponent } from './MyComponent/Student/student-result/student-result.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatButtonModule} from '@angular/material/button';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import {MatSnackBar, MatSnackBarModule} from '@angular/material/snack-bar';
import {MatTableModule} from '@angular/material/table';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SchoolmanageService } from './service/schoolmanage.service';
import { HttpClientModule } from '@angular/common/http';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { ShareDataService } from './ShareDataService';


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    TeacherDashComponent,
    TeacherAddNewDataComponent,
    TeacherEditDataComponent,
    LoginComponent,
    StudentDashComponent,
    StudentResultComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatToolbarModule,
    MatIconModule,
    MatSnackBarModule,
    MatTableModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    MatInputModule,
    FormsModule,
    HttpClientModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    ReactiveFormsModule
  ],
  providers: [MatSnackBar,SchoolmanageService,ShareDataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
