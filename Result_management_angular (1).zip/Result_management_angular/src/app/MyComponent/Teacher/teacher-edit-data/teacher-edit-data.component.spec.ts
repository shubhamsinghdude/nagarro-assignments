import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeacherEditDataComponent } from './teacher-edit-data.component';

describe('TeacherEditDataComponent', () => {
  let component: TeacherEditDataComponent;
  let fixture: ComponentFixture<TeacherEditDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TeacherEditDataComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TeacherEditDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
