import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SchoolmanageService } from 'src/app/service/schoolmanage.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-teacher-add-new-data',
  templateUrl: './teacher-add-new-data.component.html',
  styleUrls: ['./teacher-add-new-data.component.css']
})
export class TeacherAddNewDataComponent implements OnInit {

  studentData = {
    roll: "",
    name: "",
    dob: "",
    score: ""
  }
  flag=false
  btnVal=false

  constructor(private schoolmanage:SchoolmanageService, 
    private snak:MatSnackBar,
    private router: Router) { }

  ngOnInit(): void {
  }

  doSubmitForm(){
    console.log("try to submit form");
    console.log("Data: ",this.studentData);

    if(this.studentData.roll=='' ||
      this.studentData.name=='' ||
      this.studentData.dob=='' ||
      this.studentData.score==''){
        this.snak.open("fields cannot be empty","OK");
        return;
      }

    this.flag=true;
    this.btnVal=true;
    this.schoolmanage.addStudentData(this.studentData).subscribe(
      response=>{
        console.log(response)
        this.snak.open("Data Added Successfully","OK")
        this.flag=false;
        this.btnVal=false
        this.router.navigate(['/TeacherDashboard']);
        return;
      },
      error=>{
        console.log(error)
        this.snak.open(error,"OK")
        this.flag=false;
        this.btnVal=false;
      }
      
    )

  }

}
