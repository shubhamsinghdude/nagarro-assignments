import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeacherAddNewDataComponent } from './teacher-add-new-data.component';

describe('TeacherAddNewDataComponent', () => {
  let component: TeacherAddNewDataComponent;
  let fixture: ComponentFixture<TeacherAddNewDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TeacherAddNewDataComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TeacherAddNewDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
