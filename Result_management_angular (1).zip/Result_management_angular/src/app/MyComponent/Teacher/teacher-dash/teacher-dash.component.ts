import { Component, OnInit, ViewChild } from '@angular/core';
import { SchoolmanageService } from 'src/app/service/schoolmanage.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';

export interface PeriodicElement {
  Roll_Number: string;
  Name: string;
  DOB: string;
  Score: string;
  Action: string;
}



@Component({
  selector: 'app-teacher-dash',
  templateUrl: './teacher-dash.component.html',
  styleUrls: ['./teacher-dash.component.css']
})
export class TeacherDashComponent implements OnInit {

  @ViewChild('closebutton') closebutton:any;

  formValue !: FormGroup;

  bookingData:any = [];

  student = {
    id : "",
    roll: "",
    name: "",
    dob: "",
    score: ""
  }

  displayedColumns: string[] = ['Roll Number', 'Name', 'DOB', 'Score', 'Action'];

  constructor(private schoolmanage:SchoolmanageService,
    private router: Router,
    private snak:MatSnackBar,
    private formbuilder: FormBuilder) {
    this.doSubmitForm();
   }

  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      roll : [''],
      name : [''],
      dob : [''],
      score : ['']
    })
  }

  delete(j:any){
    console.log(j);
    this.schoolmanage.deleteStudentData(j).subscribe(data=>
    {
      this.doSubmitForm();
      console.log("Data deleted successfully");
      alert("Student Deleted Successfully")
    });
  }

  edit(row:any){
    this.student.id = row.id;
    this.formValue.controls['roll'].setValue(row.roll);
    this.formValue.controls['name'].setValue(row.name);
    this.formValue.controls['dob'].setValue(row.dob);
    this.formValue.controls['score'].setValue(row.score);
    // this.schoolmanage.setMessageForEdit(student);
    // this.router.navigate(['/TeacherEdit']);
    // return;
  }

  updateStudentDetails(){

    this.student.roll = this.formValue.value.roll;
    this.student.name = this.formValue.value.name;
    this.student.dob = this.formValue.value.dob;
    this.student.score = this.formValue.value.score;

    this.schoolmanage.editStudentData(this.student,).subscribe(
      response=>{
        console.log("After edit value ", response)
         this.snak.open("Data Updated Successfully","OK")
        //alert("Update Successfully")
        let ref = document.getElementById('cancel');
        ref?.click();
        this.formValue.reset();
        this.doSubmitForm();
        this.closebutton.nativeElement.click();
        // this.flag=false;
        // this.btnVal=false
        //this.router.navigate(['/TeacherDashboard']);
        return;
      },
      error=>{
        console.log(error)
        // this.snak.open(error,"OK")
        // this.flag=false;
        // this.btnVal=false;
      }
      
    )

  }



  doSubmitForm(){
    console.log("try to get data from json");
    
   
    // this.flag=true;
    // this.btnVal=true;
    this.schoolmanage.getStudentData(this.student).subscribe(
      response=>{

        this.bookingData = response;

        console.log("this is my response",this.bookingData)

        // this.snak.open("Data Added Successfully","OK")
        // this.flag=false;
        // this.btnVal=false
        // this.router.navigate(['/TeacherDashboard']);
        return;
      },
      error=>{
        console.log(error)
        // this.snak.open(error,"OK")
        // this.flag=false;
        // this.btnVal=false;
      }
      
    )

  }

}
