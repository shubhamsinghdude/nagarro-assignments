import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private snack:MatSnackBar,private router: Router) { }


  btnTeacherClick(){
    console.log("Teacher button click");
    this.snack.open("Hi teacher welcome to this app");
    this.router.navigate(['/TeacherDashboard']);
  }

  btnStudentClick(){
    console.log("Student button click");
    this.snack.open("Hi Student welcome to this app");
    this.router.navigate(['/StudentDashboard']);
  }

  ngOnInit(): void {
  }

}
