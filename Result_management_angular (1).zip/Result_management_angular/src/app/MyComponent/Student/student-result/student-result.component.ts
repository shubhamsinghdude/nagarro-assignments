import { Component, OnInit } from '@angular/core';
import { SchoolmanageService } from 'src/app/service/schoolmanage.service';

@Component({
  selector: 'app-student-result',
  templateUrl: './student-result.component.html',
  styleUrls: ['./student-result.component.css']
})
export class StudentResultComponent implements OnInit {

  roll:string = ""
  name:string = ""
  dob:string = ""
  score:string = ""
  constructor(private schoolmanage:SchoolmanageService) { }

  ngOnInit(): void {
    this.roll = this.schoolmanage.getRollMessage();
    this.name = this.schoolmanage.getNameMessage();
    this.dob = this.schoolmanage.getDobMessage();
    this.score = this.schoolmanage.getScoreMessage();
  }

}
