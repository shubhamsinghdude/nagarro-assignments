import { Component, OnInit } from '@angular/core';
import { SchoolmanageService } from 'src/app/service/schoolmanage.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-student-dash',
  templateUrl: './student-dash.component.html',
  styleUrls: ['./student-dash.component.css']
})
export class StudentDashComponent implements OnInit {

  

  roll: string = '';
  name: string = '';
  dob: string = 'pop';
  score: string = 'pop';

  bookingData: any = [];

  student = {
    id: "",
    roll: "",
    name: "",
    dob: "",
    score: ""
  }



  constructor(private schoolmanage: SchoolmanageService,
    private router: Router) { }

  ngOnInit(): void {

  }

  clickme() {
    
    console.log('it does rollN', this.roll);
    console.log('it does name', this.name);
    this.dob = "jshdus";
    // this.flag=true;
    // this.btnVal=true;
    this.schoolmanage.getOneStudentByID(this.roll).subscribe(
      response => {

        this.bookingData = response;

        console.log("this is my response", response);

        console.log("Name: ",this.name);
        console.log("org Name", this.bookingData.name);
        

        if(this.name==this.bookingData.name){
          this.dob = this.bookingData.dob;
        this.score = this.bookingData.score;
        this.schoolmanage.setMessage(this.roll, this.name, this.dob, this.score);
        this.router.navigate(['/StudentResult']);
        return;
        }else{
          alert("Your Name are not matching. Please match your name and continue")
        }

        
      },
      error => {
        console.log(error)
        alert("your roll number doesnt exist! try again")

      }

    )


    return;
  }

}
