import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SchoolmanageService {

  id:string = "";
  roll:string = "";
  name:string = "";
  dob:string = "";
  score:string = "";

  private baseUrl:string = "http://localhost:3000"

  constructor(private http:HttpClient) { }

  setMessageForEdit(studentData:any){
    this.id=studentData.id;
    this.roll=studentData.roll;
    this.name=studentData.name;
    this.dob=studentData.dob;
    this.score=studentData.score;
  }

  setMessage(roll:any,name:any,dob:any,score:any){
    this.roll=roll;
    this.name=name;
    this.dob=dob;
    this.score=score;
  }
  
  getIdMessage(){
    return this.id;
  }
  getRollMessage(){
    return this.roll;
  }
  getNameMessage(){
    return this.name;
  }
  getDobMessage(){
    return this.dob;
  }
  getScoreMessage(){
    return this.score;
  }

  addStudentData(studentData:any){
    return this.http.post(`${this.baseUrl}/student`,studentData)
  }

  getStudentData(student:any){
    return this.http.get(`${this.baseUrl}/student`,student)
  }

  deleteStudentData(id:any){
    return this.http.delete(`${this.baseUrl}/student/`+id)
  }

  editStudentData(student:any){
    return this.http.put(`${this.baseUrl}/student/`+student.id,student)
  }
  getOneStudentByID(id:any){
    return this.http.get(`${this.baseUrl}/student/`+id,)

  }

}
