import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './MyComponent/home/home.component';
import { LoginComponent } from './MyComponent/login/login.component';
import { StudentDashComponent } from './MyComponent/Student/student-dash/student-dash.component';
import { StudentResultComponent } from './MyComponent/Student/student-result/student-result.component';
import { TeacherAddNewDataComponent } from './MyComponent/Teacher/teacher-add-new-data/teacher-add-new-data.component';
import { TeacherDashComponent } from './MyComponent/Teacher/teacher-dash/teacher-dash.component';
import { TeacherEditDataComponent } from './MyComponent/Teacher/teacher-edit-data/teacher-edit-data.component';

const routes: Routes = [
  {
    path : "",
    component : HomeComponent,
    pathMatch : "full"
  },
  {
    path : "TeacherDashboard",
    component : TeacherDashComponent,
    pathMatch : "full"
  },
  {
    path : "TeacherEdit",
    component : TeacherEditDataComponent,
    pathMatch : "full"
  },
  {
    path : "TeacherAddData",
    component : TeacherAddNewDataComponent,
    pathMatch : "full"
  },
  {
    path : "StudentDashboard",
    component : StudentDashComponent,
    pathMatch : "full"
  },
  {
    path : "StudentResult",
    component : StudentResultComponent,
    pathMatch : "full"
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
