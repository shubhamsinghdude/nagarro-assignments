export class student
{
    id : string;
    rollNum : string;
    name : string;
    dob : string;
    score : string;

    constructor(id:any,rollNum:any,name:any,dob:any,score:any){
        this.id = id;
        this.rollNum = rollNum;
        this.name = name;
        this.dob = dob;
        this.score = score;
    }
}