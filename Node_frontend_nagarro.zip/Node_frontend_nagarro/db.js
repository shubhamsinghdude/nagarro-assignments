const Sequelize = require('sequelize');
const db = new Sequelize('node_nagarro', 'root', 'password', {
    host: "localhost",
    dialect: "mysql"
});

module.exports = db;
