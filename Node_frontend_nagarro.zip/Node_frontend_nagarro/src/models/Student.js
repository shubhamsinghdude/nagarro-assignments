const Sequelize = require("sequelize");
const db = require('../../db');

module.exports = db.define('Student', {
    // id: {
    //     type: Sequelize.INTEGER(11),
    //     allowNull: false,
    //     primaryKey: true,
    // },
    name: {
        type: Sequelize.STRING,
        allowNull: false
    },
    roll: {
        type: Sequelize.STRING,
        allowNull: false,
        unique: true
    },
    dob: {
        type: Sequelize.STRING,
        allowNull: false
    },
    score: {
        type: Sequelize.STRING,
        allowNull: false
    }
});
