const Student = require('../models/Student');

const getAllStudent = async (req, res)=> {
    const students = await Student.findAll({
        raw:true
    }).catch(error=>console.log(error))
    await res.render('home',{students});
}

const addStudent = async (req, res)=> {
    await res.render('createStudent');
}


const saveStudent = async (req, res)=> {
    const {name, roll, dob, score } = await req.body;
    const student = await Student.create({
        name:name, roll:roll, dob: dob, score:score
    }).catch(error=>console.log(error))
    console.log(student)
    res.redirect('/teacherHome');
    await res.render('createStudent');
}

const editStudent = async (req, res)=>{
    const {id} = await req.params;
    const student = await Student.findOne({
        where:{
            id:id
        },
        raw:true
    }).catch(error=>console.log(error));
    res.render('updateStudent',{student})
}

const updateStudent = async (req, res)=>{
    const {id} = req.params;
    const data = req.body;
    const selector = {where:{id:id}}
    await Student.update(data, selector).catch(error=>console.log(error))

    res.redirect('/teacherHome')
}

const viewStudent = async (req, res)=>{
    const {id} = req.params;
    const student = await Student.findOne({
        where:{
            roll:req.body.roll,
            name:req.body.name
        },
        raw:true
    }
    ).catch(error=>console.log(error));
    if(!student){
        res.render("searchStudent",{error:"No Data Found"})
    }

    res.render('showSingleStudent',{student})
}

const deleteStudent = async (req, res)=>{
    const {id} = req.params;
    const student = await Student.destroy({
        where:{
            id:id
        },
        raw:true
    }).catch(error=>console.log(error));

    res.redirect('/teacherHome')
}

module.exports = {
    getAllStudent,
    addStudent,
    saveStudent,
    editStudent,
    updateStudent,
    viewStudent,
    deleteStudent
}