const express = require('express');
// const { getAllStudent } = require('../controllers/studentController');
const router = express.Router();
const {getAllStudent, addStudent, saveStudent, editStudent, updateStudent, viewStudent, deleteStudent} = require('../controllers/studentController');

router.get('/', getAllStudent);
router.get('/create', addStudent);
router.post('/create', saveStudent);
router.get('/edit/:id', editStudent);
router.post('/update/:id', updateStudent);
router.get('/student/:id', viewStudent);
router.get('/delete/:id', deleteStudent);

module.exports = router;