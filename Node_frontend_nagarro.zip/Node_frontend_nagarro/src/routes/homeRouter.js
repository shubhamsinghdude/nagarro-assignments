const express = require('express');
// const { getAllStudent } = require('../controllers/studentController');
const homeRouter = express.Router();
homeRouter.get("",(req,res)=>{
  res.redirect("login")
})
