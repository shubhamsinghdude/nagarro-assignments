'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    /**
     * Add altering commands here.
     *
     */
     await queryInterface.createTable('student', { 

    //   id: {
    //     type: Sequelize.INTEGER(11),
    //     allowNull: false,
    //     primaryKey:true
    // },
    name: {
        type: Sequelize.STRING,
        allowNull: false
    },
    roll: {
        type: Sequelize.STRING,
        allowNull: false
    },
    dob: {
        type: Sequelize.STRING,
        allowNull: false
    },
    score: {
        type: Sequelize.STRING,
        allowNull: false
    },
    createdAt:Sequelize.DATE,
    updatedAt:Sequelize.DATE

     });

  },

  async down (queryInterface, Sequelize) {
    /**
     * Add reverting commands here.
     *
     */
    await queryInterface.dropTable('student');

  }
};
