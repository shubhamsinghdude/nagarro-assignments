package carInsurance;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MyMainClass {
	
	public static Scanner sc;
	
	public static String inputCarModel() {
		
		sc = new Scanner(System.in);
		System.out.print("Car model name -> ");
		return sc.nextLine();

	}
	
	public static String inputCarType() {
		
		sc = new Scanner(System.in);
		System.out.print("Car type - 1.Hatchback 2.Sedan 3.SUV -> ");
		String carType="";
		try {
			
			int chosenValue = sc.nextInt();
			switch(chosenValue) {
			case 1:
				carType = "Hackback";
				break;
				
			case 2:
				carType = "Sedan";
				break;
				
			case 3:
				carType = "SUV";
				break;
			default:
				carType = "";
				break;
			
			}
		}
		catch(NumberFormatException nf) {
			System.out.print("Please type Int value only");
		}
		catch(Exception ex) {
			System.out.print("Something went wrong");
		}
		
		return carType;
	}
	
	public static int carCostPrice() {
		
		int carCostPrice=-1;
		sc = new Scanner(System.in);
		try {
			System.out.print("Car Cost Price -> ");
			carCostPrice = sc.nextInt();
		}
		catch(NumberFormatException nf) {
			System.out.print("Please type Int value only");
		}
		catch(Exception ex) {
			System.out.print("Something went wrong");
		}
		return carCostPrice;
		
	}
	
	public static String carInsuranceType() {
		
		System.out.print("Insurance type - 1.Basic  2.Premium -> ");
		sc = new Scanner(System.in);
		String carType="";
		try {
			int chosenValue = sc.nextInt();
			
			switch(chosenValue) {
			case 1:
				carType = "Basic";
				break;
				
			case 2:
				carType = "Premium";
				break;
				
			}
		}
		catch(InputMismatchException ime) {
			System.out.print("Please type Int value only");
		}
		catch(Exception ex) {
			System.out.print("Something went wrong");
		}
		return carType;
		
		
	}
	
	public static int calcuateInsurance(Car car) {
		
		int answer=0;
		int intrest=0;
		int extraIntrest=0;
		switch(car.getCarType()) {
		case "Hatchback":
			intrest = (int) ((int) car.getCarCostPrice() * 0.05);
			break;
		
		case "Sedan":
			intrest = (int) ((int) car.getCarCostPrice() * 0.08);
			break;
			
		case "SUV":
			intrest = (int) ((int) car.getCarCostPrice() * 0.1);
			break;
		}
		
		switch(car.getInsuranceType()) {
		
		case "Basic":
			extraIntrest = 0;
			break;
			
		case "Preminum":
			extraIntrest = (int) ((int) intrest * 0.2);
			
		}
		
		answer =  (car.getCarCostPrice() + intrest + extraIntrest);
		return answer;
	}

	public static Car inputValue() {
		
		String v1,v2,v4;
		int v3;
		v1 = inputCarModel();
		
		while(true) {
			String temp = inputCarType();
			if(temp == "Hackback" || temp == "Sedan" || temp == "SUV") {
				v2 = temp;
				break;
			}
			System.out.println(" Please type valid input!, Try again");
		}
		
		while(true) {
			int temp = carCostPrice();
			if(temp!=-1) {
				v3 = temp;
				break;
			}
			System.out.println(" Please tyep valid input!, Try again");
		}
		
		while(true) {
			String temp = carInsuranceType();
			if(temp == "Basic" || temp == "Premium") {
				v4 = temp;
				break;
			}
			System.out.println(" Please type valid input!, Try again");
		}
		
		Car car = new Car(v1,v2,v3,v4);
		return car;
	}
	
	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		ArrayList<Integer> amt = new ArrayList<>();
		ArrayList<String> para = new ArrayList<>();
		System.out.println("Welcome to the car insurence company");
		int check = 1;
		while(true) {
			
			Car car = inputValue();
			System.out.println("Thanks for the information, Do you want to enter details of any other car (1/2):");
			String temp = "Car Model - "+car.getCarModel();
			int InsurTemp = calcuateInsurance(car);
			amt.add(InsurTemp);
			para.add(temp);
			System.out.print("1. Yes   2. No -> ");
			check = sc.nextInt();
			if(check==2) {
				break;
			}
		}

		int totalAmt=0;
		System.out.println("Here is your Information");
		for(int i=0;i<amt.size();i++) {
			totalAmt +=amt.get(i);
			System.out.println((i+1) + ". " + para.get(i) + " and Insurence amt is: " + amt.get(i)  );
		}
		System.out.println("Total amt is: " +totalAmt);
		

	}
	
}
