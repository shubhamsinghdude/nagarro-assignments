import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ManageService } from 'src/app/service/manage.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NavbarManageService } from 'src/app/service/nav/navbar-manage.service';



@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  public searchFilter: any = '';

  public query: any = '';

  formValue !: FormGroup;

  constructor(private manage: ManageService,
    private formbuilder: FormBuilder,
    private snak: MatSnackBar,
    public nav: NavbarManageService ) { }

  product = []

  ngOnInit(): void {
    this.nav.show();

    this.formValue = this.formbuilder.group({
      productCode: [''],
      name: [''],
      brand: [''],
      price: [''],
      description: ['']
    })

    this.manage.getProductData().subscribe((data: any) => {

      console.log("Product1")
      console.log(data);
      this.product = data;
      console.log("Product data fetched and also upload in product list")
    });

  }

  checkService(data: any) {
    // var deliveryTime = data.deliveryDate;
    var today = new Date();
    // tomorrow.setDate(tomorrow.getDate() + deliveryTime);

    var nextDay = new Date(today);
    nextDay.setDate(today.getDate() + 5);
    console.log(nextDay);
    // var deliveryDate = tomorrow.toISOString().split('T')[0]
    let  deliveryDate  = nextDay+"";
    
    this.snak.open("Your delivery date is: " + deliveryDate.slice(0, 15), "OK");
  }

  viewDetails(data: any) {
    this.formValue.controls['productCode'].setValue(data.productCode);
    this.formValue.controls['name'].setValue(data.name);
    this.formValue.controls['brand'].setValue(data.brand);
    this.formValue.controls['price'].setValue(data.price);
    this.formValue.controls['description'].setValue(data.description);
  }

}
