import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ManageService } from 'src/app/service/manage.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  user = {
    mail: "",
    firstName: "",
    lastName: "",
    password: ""
  }
  userData = {
    Email: "",
    first: "",
    last: "",
    pass: "",
    cnfPass: ""
  }
  flag = false
  btnVal = false

  constructor(private manage: ManageService,
    private snak: MatSnackBar,
    private router: Router) { }

  ngOnInit(): void {
  }

  doSubmitForm() {

    const yourEmail = this.userData.Email;
    const yourpass = this.userData.pass;


    console.log("try to submit form");
    console.log("userData data: ", this.userData);

    if (this.userData.pass == '' || this.userData.cnfPass == '') {
      this.snak.open("Passwords does not match", "OK");
      return;
    }
    if (this.userData.first == '' || this.userData.last == '') {
      this.snak.open("Please fill your full name", "OK");
      return;
    }

    if (this.userData.Email == '' || this.userData.first == '' ||
      this.userData.last == '' || this.userData.pass == '' || this.userData.cnfPass == '') {
      this.snak.open("fields cannot be empty", "OK");
      return;
    }
    if (this.userData.pass != this.userData.cnfPass) {
      this.snak.open("Both Password does not match", "OK");
      return;
    }

    if (!yourEmail.includes('@') || !yourEmail.includes('.')) {
      this.snak.open("Your email is not valid, Please check", "OK");
      return;
    }
    if (yourpass.length <= 8) {
      this.snak.open("Password must be grater than 8 digit", "OK");
      return;
    }

    if (!yourpass.includes('@') || !yourpass.includes('*') || !yourpass.includes('#')) {
      this.snak.open("Please use '@', '*', '#' all symbols in your password", "OK");
      return;
    }

    this.user.mail = this.userData.Email;
    this.user.firstName = this.userData.first;
    this.user.lastName = this.userData.last;
    this.user.password = this.userData.pass;

    this.flag = true;
    this.btnVal = true;

    console.log("user data: ", this.user);
    this.manage.signup(this.user).subscribe(
      response => {
        console.log(response)
        this.snak.open("Account Created Successfully", "OK")
        this.flag = false;
        this.btnVal = false
        this.router.navigate(['/dashboard']);
        return;
      },
      error => {
        console.log(error)
        this.snak.open("Something went wrong", "OK")
        this.flag = false;
        this.btnVal = false;
      }

    )

  }

}
