import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ManageService } from 'src/app/service/manage.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userData = []

  studentData = {
    mail: "",
    password: ""
  }
  flag = false
  btnVal = false

  constructor(private manage: ManageService,
    private snak: MatSnackBar,
    private router: Router) { }

  ngOnInit(): void {
  }

  doSubmitForm(mail: any, password: any) {

    const yourEmail = this.studentData.mail;
    const yourpass = this.studentData.password;

    if (this.studentData.mail == '' && this.studentData.password == '') {
      this.snak.open("Both fields cannot be empty", "OK");
      return;
    }
    if (!this.studentData.mail) {
      this.snak.open("Email fields cannot be empty", "OK");
      return;
    }
    if (!this.studentData.password) {
      this.snak.open("Password fields cannot be empty", "OK");
      return;
    }

    if (!yourEmail.includes('@') || !yourEmail.includes('.')) {
      this.snak.open("Your email is not valid, Please check", "OK");
      return;
    }
    if (yourpass.length <= 8) {
      this.snak.open("Password must be grater than 8 digit", "OK");
      return;
    }

    // if (!yourpass.includes('@') || !yourEmail.includes('*') || !yourEmail.includes('#')) {
    //   this.snak.open("Please use '@', '*', '#' all symbols in your password", "OK");
    //   return;
    // }
    this.manage.getUserData().subscribe((data: any) => {

      console.log("Product1")
      console.log(this.userData);
      this.userData = data;
      console.log(this.userData);
      console.log("Product data fetched and also upload in product list")

      var m = false;
      var p = false;
      for (var i = 0; i < this.userData.length; i++) {
        var person = this.userData[i];
        for (let x in person) {
          if (person[x] == mail) m = true;
          if (person[x] == password) p = true;
        }
      }
      if (m == true && p == true) {
        this.snak.open("Successfully Login", "OK");
        this.router.navigate(['/dashboard']);
        return;
      } 
      if (m == false) {
        this.snak.open("Account does not exist", "OK");
        return;
      }
      if (m == true && p == false) {
        this.snak.open("Password does not match", "OK");
        return;
      }else {
        return;
      }
    });


    // console.log("try to submit form");
    // console.log("Data: ",this.studentData);

    // if(this.studentData.roll=='' ||
    //   this.studentData.name==''){
    //     this.snak.open("fields cannot be empty","OK");
    //     return;
    //   }

    // this.flag=true;
    // this.btnVal=true;


    // this.manage.getUserData().subscribe(
    //   response=>{
    //     console.log(response)
    //     // this.snak.open("Data Added Successfully","OK")
    //     // this.flag=false;
    //     // this.btnVal=false
    //     // this.router.navigate(['/TeacherDashboard']);
    //     return;
    //   },
    //   error=>{
    //     console.log(error)
    //     this.snak.open(error,"OK")
    //     this.flag=false;
    //     this.btnVal=false;
    //   }

    // )

  }

}
