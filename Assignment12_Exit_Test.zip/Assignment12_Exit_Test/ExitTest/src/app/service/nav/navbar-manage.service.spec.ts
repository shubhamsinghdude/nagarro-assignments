import { TestBed } from '@angular/core/testing';

import { NavbarManageService } from './navbar-manage.service';

describe('NavbarManageService', () => {
  let service: NavbarManageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NavbarManageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
