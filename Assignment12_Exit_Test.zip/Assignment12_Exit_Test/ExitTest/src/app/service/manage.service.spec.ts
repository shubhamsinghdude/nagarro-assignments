import { TestBed } from '@angular/core/testing';

import { ManageService } from './manage.service';

describe('SchoolmanageService', () => {
  let service: ManageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ManageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
