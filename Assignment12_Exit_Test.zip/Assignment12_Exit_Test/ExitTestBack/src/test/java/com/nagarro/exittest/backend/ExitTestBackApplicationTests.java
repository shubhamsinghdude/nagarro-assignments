package com.nagarro.exittest.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExitTestBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
