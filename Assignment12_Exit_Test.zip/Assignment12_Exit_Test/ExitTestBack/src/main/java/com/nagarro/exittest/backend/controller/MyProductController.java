package com.nagarro.exittest.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nagarro.exittest.backend.model.Product;
import com.nagarro.exittest.backend.service.ProductService;

@RestController
@CrossOrigin(origins = "*")
public class MyProductController {
	
	@Autowired
	private ProductService productService ;
	
	@GetMapping("/product")
	public List<Product> getAllProduct() {
		return this.productService.getProducts();
	}
	
	@GetMapping("/product/{productId}")
	public Product getProduct(@PathVariable String productId) {
		return this.productService.getProduct(Integer.parseInt(productId));
	}
	
	@PostMapping("/product")
	public Product addProduct(@RequestBody Product product) {
		return this.productService.addProduct(product);
	}
	
	
	//Get Description
	//@GetMapping("/product/{productId}")
//	public String getProductDescription(@PathVariable String productId) {
//		return this.productService.getProductDescription(Long.parseLong(productId));
//	}
	
	//Get Price
	//@GetMapping("/product/{productId}")
//	public String getPriceOfProduct(@PathVariable String productId) {
//		return this.productService.getPriceOfProduct(Long.parseLong(productId));
//	}
	
	//Get Delivery Date
	//@GetMapping("/product/{productId}")
//	public String getServiceabilityOfProduct(@PathVariable String productId) {
//		return this.productService.getServiceabilityOfProduct(Long.parseLong(productId));
//	}
	
	
	
	
	


}
