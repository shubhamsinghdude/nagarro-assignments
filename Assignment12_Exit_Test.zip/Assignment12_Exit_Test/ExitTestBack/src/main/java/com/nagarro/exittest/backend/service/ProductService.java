package com.nagarro.exittest.backend.service;

import java.util.List;

import com.nagarro.exittest.backend.model.Product;

public interface ProductService {
	
	//For Exit Test API
//	public List<Product> getProductsFromName(String name);
//	
//	public List<Product> getProductsFromProductCode(String productCode);
//	
//	public List<Product> getProductsFromBrand(String brand);
//	
//	public String getProductDescription(long productId);
//	
//	public String getPriceOfProduct(long productId);
//	
//	public String getServiceabilityOfProduct(long productId);
	
	
	//For My Use
	public Product addProduct(Product product);

	public List<Product> getProducts();
	
	public Product getProduct(int productId);

}
