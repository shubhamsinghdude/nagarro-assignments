package com.nagarro.exittest.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.nagarro.exittest.backend.dao.UserRepository;
import com.nagarro.exittest.backend.model.User;

@SpringBootApplication
public class ExitTestBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExitTestBackApplication.class, args);
		
//		UserRepository userRepository = context.getBean(UserRepository.class);
//		
//		User user =new User();
//		user.setFirstName("Shubham");
//		user.setLastName("Singh");
//		user.setMail("Shubhamsatna9074@gmail.com");
//		user.setPassword("123456");
//		
//		User u1 = userRepository.save(user);
//		
//		System.out.println(u1);
		
	}

}
