package com.nagarro.exittest.backend.service;

import java.util.List;

import com.nagarro.exittest.backend.model.User;

public interface UserService {
	
	public User addUser(User user);

	public List<User> getUsers();
	
	public User getUser(int userId);
	
	public User loginAuth(String username,String password);

}
