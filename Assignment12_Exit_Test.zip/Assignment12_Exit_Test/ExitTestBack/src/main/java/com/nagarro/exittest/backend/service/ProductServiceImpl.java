package com.nagarro.exittest.backend.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nagarro.exittest.backend.dao.ProductDao;
import com.nagarro.exittest.backend.model.Product;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductDao productDao;

	@Override
	public List<Product> getProducts() {
		// TODO Auto-generated method stub
		return productDao.findAll();
	}

	@SuppressWarnings("deprecation")
	@Override
	public Product getProduct(int productId) {
		return productDao.getById(productId);
	}
	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		productDao.save(product);
		return product;
	}

//	@Override
//	public List<Product> getProductsFromName(String name) {
//		// TODO Auto-generated method stub
//		List<Product> tempList = new ArrayList<>();
//
//		for (Product product : list) {
//			if (product.getName() == name)
//				tempList.add(product);
//		}
//		return tempList;
//	}
//
//	@Override
//	public List<Product> getProductsFromProductCode(String productCode) {
//		
//		List<Product> tempList = new ArrayList<>();
//
//		for (Product product : list) {
//			if (product.getProductCode() == productCode)
//				tempList.add(product);
//		}
//		return tempList;
//	}
//
//	@Override
//	public List<Product> getProductsFromBrand(String brand) {
//		
//		List<Product> tempList = new ArrayList<>();
//
//		for (Product product : list) {
//			if (product.getBrand() == brand)
//				tempList.add(product);
//		}
//		return tempList;
//	}
//
//	@Override
//	public String getProductDescription(long productId) {
//		
//		for (Product product : list) {
//			if (product.getId() == productId) 
//				return product.getDescription();
//		}
//		return null;
//	}
//
//	@Override
//	public String getPriceOfProduct(long productId) {
//		
//		for (Product product : list) {
//			if (product.getId() == productId) 
//				return product.getPrice();
//		}
//		return null;
//	}
//
//	@Override
//	public String getServiceabilityOfProduct(long productId) {
//		
//		for (Product product : list) {
//			if (product.getId() == productId) 
//				return product.getDeliveryDate();
//		}
//		return null;
//	}

}
