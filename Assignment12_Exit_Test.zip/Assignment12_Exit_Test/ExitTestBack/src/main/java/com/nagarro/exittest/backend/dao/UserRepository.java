package com.nagarro.exittest.backend.dao;

import org.springframework.data.repository.CrudRepository;

import com.nagarro.exittest.backend.model.User;

public interface UserRepository extends CrudRepository<User, Integer> {

}
