package com.nagarro.exittest.backend.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nagarro.exittest.backend.dao.UserDao;
import com.nagarro.exittest.backend.model.User;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDao userDao;

	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return userDao.save(user);
	}

	@Override
	public List<User> getUsers() {
		// TODO Auto-generated method stub
		return userDao.findAll();
	}

	@Override
	public User getUser(int userId) {
		// TODO Auto-generated method stub
		return userDao.getOne(userId);
	}

	@Override
	public User loginAuth(String username, String password) {
		// TODO Auto-generated method stub
		User user = new User();
		List<User> list = this.getUsers();
		for(int i=0;i<list.size();i++) {
			if(list.get(i).getMail()==username && list.get(i).getPassword()==password) {
				user=list.get(i);
			}
		}
		return user;
	}

}
