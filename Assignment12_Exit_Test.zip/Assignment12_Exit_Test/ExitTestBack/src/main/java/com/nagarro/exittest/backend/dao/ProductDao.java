package com.nagarro.exittest.backend.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nagarro.exittest.backend.model.Product;

public interface ProductDao extends JpaRepository<Product, Integer> {
	

}
