package com.nagarro.exittest.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.nagarro.exittest.backend.model.User;
import com.nagarro.exittest.backend.model.UserAuth;
import com.nagarro.exittest.backend.service.UserService;

@RestController
@CrossOrigin(origins = "*") 
public class MyUserController {
	
	@Autowired
	private UserService userService;
	
	@GetMapping("/user")
	public List<User> getAllUser() {
		return this.userService.getUsers();
	}
	
//	@GetMapping("/user/(auth)")
//	public User userAuth(@RequestBody UserAuth userAuth) {
//		return  this.userService.loginAuth(userAuth.getMail(), userAuth.getPassword());
//	}
	
	@GetMapping("/user/{userId}")
	public User getUser(@PathVariable String userId) {
		return this.userService.getUser(Integer.parseInt(userId));
	}
	
	@PostMapping("/user")
	public User addUser(@RequestBody User user) {
		return this.userService.addUser(user);
	}

}
